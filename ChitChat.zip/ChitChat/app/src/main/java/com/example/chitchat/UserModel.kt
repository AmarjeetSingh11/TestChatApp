package com.example.chitchat

data class UserModel(
    val uid:String,
    val name:String,
    val number:String,
    val image:String
)
